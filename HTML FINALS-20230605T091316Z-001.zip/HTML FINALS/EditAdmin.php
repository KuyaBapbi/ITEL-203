<?php
include("partials/_dbconnect.php");


if($_SERVER['REQUEST_METHOD'] == 'POST'){
    // POST
    $name = $_POST["name"];
    $email = $_POST["email"];
    $password = $_POST["password"];
    
    do{
        if(empty($name) || empty($email) || empty($password)){
            $errorMessage = "All of the fields are required";
            break;
        }
        // add new client to database
        $query = "update `users` set name = '$name',email = '$email',password = '$password' where Email = '$email'";
        $result = $conn -> query($query);
        if(!$result){
            $errorMessage = "Invalid query: " . $conn -> error;
            break;
        }
        $successMessage = "Data Successfully Updated!";
        header("refresh:3;url= AccountAdmin.php");
        $name = "";
        $email = "";
        $password ="";
    }while(false);
}

?>

<!DOCTYPE html>
 <html>
 <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css"
        integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="css/navbar.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="css/index.css">
    <title>EDIT USERS</title>
    <style>
        h2{
            color:  white;
            text-align: center;
        }
    </style>
</head>
 <body>
     <?php include 'partials/_navbarAdmin.php'; ?>

<div class="cover"></div>
<h2>Update Client</h2>
<div class="createUser">
    <div class="userdata">
        <form method="POST">
            <input type="hidden" name ="admins"/>
            <div class = "row mb-3">
                <div class ="col-sm-6">
                    <input id="name" type="name" placeholder="NAME" name="name" required/>
                </div>
            </div>
            <div class = "row mb-3">
                <div class ="col-sm-6">
                    <input id="email" type="email" placeholder="EMAIL" name="email" required/>
                </div>
            </div>
            <div class = "row mb-3">
                <div class ="col-sm-6">
                    <input id="password" type="password" placeholder="PASSWORD" name="password" required/>
                </div>
            </div>
            <div class = "row mb-4">
                <div class="offset-sm-3 col-sm-2 d-grid">
                    <button type="submit" class="btn btn-primary">UPDATE USERS</button>
                </div>
                <div class="col-sm-3 col-sm-2 d-grid">
                    <button type="submit" class="btn btn-primary" href="AccountAdmin.php"/>CANCEL EDITING
                </div>
            </div>
        </form>
    </div>
</div>

    <?php include 'partials/_footer.php'; ?>
    <!-- script  -->
    <script src="js/navscroll.js"></script>
 </body>
 </html>