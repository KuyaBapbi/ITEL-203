<?php

    echo'<div class="nevbar" id="nevbar">
    <div class="">
    </div>
    <div class="menu" id="menu"> 
        <ul>
            <li><a id="home" href="index.php">Home</a></li>
            <li><a id="home" href="all_user.php">All Users</a></li>
            <li><a id="contact" href="contact.php">Contact</a></li>
        </ul> 
    </div>
    <div class="menuicon">
        <i id="menuicon" onclick="togglemenu()" class="fas fa-chevron-circle-down"> <span>MENU</span></i>
    </div>
</div>
<div class="topspace"></div>' ;

?>