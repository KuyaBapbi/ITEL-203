_<?php

    echo'<div class="nevbar" id="nevbar">
    <div class="logo">
        <a href="index.php" id="logo"><h1><span>YBI</span> Bank</h1></a>
    </div>
    <div class="menu" id="menu"> 
        <ul>
            <li><a id="home" href="AccountUser.php">Home</a></li>
            <li><a id="home" href="BalanceUser.php">Balance</a></li>
            <li><a id="home" href="Withdraw.php">Withdraw</a></li>
            <li><a id="home" href="Deposit.php">Deposit</a></li>
            <li><a id="home" href="transfer_logUser.php">Transaction Log</a></li>
            <li><a id="contact" href="contactAccount.php">Contact</a></li>
            <li><a id="contact" href="index.php">Logout</a></li>
        </ul> 
    </div>
    <div class="menuicon">
        <i id="menuicon" onclick="togglemenu()" class="fas fa-chevron-circle-down"> <span>MENU</span></i>
    </div>
</div>
<div class="topspace"></div>' ;

?>