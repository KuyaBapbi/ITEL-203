<?php

    echo'<div class="nevbar" id="nevbar">
    <div class="logo">
        <a href="index.php" id="logo"><h1><span>YBI</span> Bank</h1></a>
    </div>
    <div class="menu" id="menu"> 
        <ul>
            <li><a id="home" href="AccountAdmin.php">Home</a></li>
            <li><a id="home" href="all_userAdmin.php">All Users</a></li>
            <li><a id="home" href="create_userAdmin.php">Create User</a></li>
            <li><a id="home" href="transfer_moneyAdmin.php">Transfer Money</a></li>
            <li><a id="home" href="DepositAdmin.php">Deposit</a></li>
            <li><a id="home" href="transfer_logAdmin.php">Transaction Log</a></li>
            <li><a id="contact" href="EditAdmin.php">Update User</a></li>
            <li><a id="contact" href="contactAdmin.php">Contact</a></li>
            <li><a id="contact" href="index.php">Logout</a></li>

        </ul> 
    </div>
    <div class="menuicon">
        <i id="menuicon" onclick="togglemenu()" class="fas fa-chevron-circle-down"> <span>MENU</span></i>
    </div>
</div>
<div class="topspace"></div>' ;

?>