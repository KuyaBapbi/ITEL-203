<?php
include 'connect.php';

if(isset($_GET['Student_Id'])){
    $Student_Id = $_GET['Student_Id'];
    $query_delete = "DELETE FROM studentlist where Student_Id = '$Student_Id'";
    $conn -> query($query_delete);
    if ($conn) {
        header('location:index.php');
    } else {
        echo "Error:".$query($conn);
    }
}
?>