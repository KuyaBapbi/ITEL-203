<?php
session_start();
include("connect.php");

if(!isset($_SESSION["Start"])){
header("location: /STUDENTSLIST/index.php");
}



$Student_Id = "";
$Student_name = "";
$Course = "";
$Section = "";
$Age = "";
$errorMessage = "";
$successMessage = "";
if($_SERVER['REQUEST_METHOD'] == 'POST'){
    $Student_Id = $_POST["Student_Id"];
    $Student_name = $_POST["Student_name"];
    $Course = $_POST["Course"];
    $Section = $_POST["Section"];
    $Age = $_POST["Age"];
    
    do{
        if(empty($Student_Id) || empty($Student_name) || empty($Course) || empty(($Section) || empty($Age))){
            $errorMessage = "All of the fields are required";
            break;
        }
        // update studentlist to database
        $query = "UPDATE studentlist SET Student_Id='$Student_Id', Student_name='$Student_name', Course='$Course', Section='$Section', Age='$Age' WHERE Student_Id='$Student_Id'";
        
        $result = $conn -> query($query);
        if(!$result){
            $errorMessage = "Invalid query: " . $conn -> error;
            break;
        }
        $successMessage = "Updated Successfully!";
        $Student_Id = "";
        $Student_name = "";
        $Course ="";
        $Section ="";
        $Age = "";
    }while(false);
}

?>

<!DOCTYPE html>
 <html>
 <head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Edit StudentList</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-MrcW6ZMFYlzcLA8Nl+NtUVF0sA7MsXsP1UyJoMp4YLEuNSfAP+JcXn/tWtIaxVXM" crossorigin="anonymous"></script>
</head>
 <body>
    <div class="container my-5">
        <h2>Edit Student</h2>
        <?php
        if(!empty($errorMessage)){
            echo "
            <div class='alert alert-warning alert-dismissible fade show' role ='alert'>
            <strong>$errorMessage<strong>
            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'/>
            </div>
            ";
        }
        ?>
        <form method="post" action = "edit.php">
            <div class = "row mb-3">
                <label class="col-sm-3 col-form-label">Student ID</label>
                <div class ="col-sm-6">
                    <input type="text" class ="form-control" name="Student_Id" value ="<?php echo $Student_Id;?>"/>
                </div>
            </div>
            <div class = "row mb-3">
                <label class="col-sm-3 col-form-label">Student Name</label>
                <div class ="col-sm-6">
                    <input type="text" class ="form-control" name="Student_name" value ="<?php echo $Student_name;?>"/>
                </div>
            </div>
            <div class = "row mb-3">
                <label class="col-sm-3 col-form-label">Course</label>
                <div class ="col-sm-6">
                    <input type="text" class ="form-control" name="Course" value ="<?php echo $Course;?>"/>
                </div>
            </div>
            <div class = "row mb-3">
                <label class="col-sm-3 col-form-label">Section</label>
                <div class ="col-sm-6">
                    <input type="text" class ="form-control" name="Section" value ="<?php echo $Section;?>"/>
                </div>
            </div>
            <div class = "row mb-3">
                <label class="col-sm-3 col-form-label">Age</label>
                <div class ="col-sm-6">
                    <input type="text" class ="form-control" name="Age" value ="<?php echo $Age;?>"/>
                </div>
            </div>

            <?php
            if(!empty($successMessage)){
                echo "
                <div class ='row mb-3'>
                    <div class ='offset-sm-3 col-sm-6'>
                        <div class='alert alert-success alert-dismissible fade show' role ='alert'>
                            <strong>$successMessage<strong>
                            <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'/>
                        </div>
                    </div>
                </div>
                
                ";
            }
            ?>

            <div class = "row mb-4">
                <div class="offset-sm-3 col-sm-2 d-grid">
                    <button type="submit" class="btn btn-primary">Update</button>
                </div>
                <div class="col-sm-2 col-sm-2 d-grid">
                    <a type="submit" class="btn btn-danger" href="./index.php">Cancel</a>
                </div>
            </div>
        </form>
    </div>
 </body>
 </html>