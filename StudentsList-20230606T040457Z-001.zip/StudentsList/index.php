<?php
session_start();
// session_destroy();
if(isset($_POST["submit"])){
    echo "You clicked submit!";
    $_SESSION["Start"] = "Now";
    header("location: /STUDENTSLIST/create.php");
}
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>StudentList</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-EVSTQN3/azprG1Anm3QDgpJLIm9Nao0Yz1ztcQTwFspd3yD65VohhpuuCOmLASjC" crossorigin="anonymous">
    <title>My Shop</title>
</head>
<body>
    <div class="container my-5">
        <h2>List of Students</h2>
        <form method="POST" ACTION ="edit.php">
        <button class ="btn btn-primary" name="submit">Update</button>
        </form> <br>
        <form method="POST" ACTION ="index.php">
        <button class ="btn btn-primary" name="submit">Create New StudentList</button>
        </form>
        <br/> <br/>
        <div class="card">
            <div class="card-body" style ="margin:50px">
                <table class ="table">
                    <thead>
                        <tr>
                            <th>Student ID</th>
                            <th>Student Name</th>
                            <th>Course</th>
                            <th>Section</th>
                            <th>Age</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $servername = "localhost";
                        $username = "root";
                        $password = "";
                        $database = "students";
                        $con = new mysqli($servername, $username,$password,$database);
                        $con->set_charset("utf8");
                        if($con -> connect_error){
                            die("Connection Failed: ". $con -> connect_error);
                        }
                        $query = "SELECT * FROM studentlist";
                        $result = $con->query($query);
                        if(!$result){
                            die("Invalid query!!". $con -> error);
                        }
                        while($row = $result->fetch_assoc()){
                            echo "
                                <tr>
                                <td>".$row['Student_Id']."</td>
                                <td>".$row['Student_name']."</td>
                                <td>".$row['Course']."</td>
                                <td>".$row['Section']."</td>
                                <td>".$row['Age']."</td>
                                <td>

                                <a href='delete.php? Student_Id=$row[Student_Id]' class='btn'>Delete</a>
                                </td>
                                </tr>
                            ";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
    </div>
</body>
</html>